#include <Wire.h>
#include <LiquidCrystal_I2C.h> 
#include <DS3231.h> // https://github.com/jarzebski/Arduino-DS3231/archive/master.zip // DS3231.zip
#include <EEPROM.h> 

DS3231 clock;
RTCDateTime DateTime;

LiquidCrystal_I2C lcd(0x27, 20, 4); // Встановлюємо дисплей

// Custom characters / Власний шрифт
byte v1[8] = {7, 15, 15, 15, 15, 15, 15, 7};
byte v2[8] = {7, 15, 15, 0, 0, 0, 0, 0};
byte v3[8] = {0, 0, 0, 0, 0, 0, 31, 31};
byte v4[8] = {31, 31, 0, 0, 0, 0, 31, 31};
byte v5[8] = {30, 30, 14, 0, 0, 0, 0, 0};
byte v6[8] = {28, 30, 30, 30, 30, 30, 30, 28};
byte v7[8] = {0, 0, 0, 0, 0, 15, 15, 7};
byte v8[8] = {31, 31, 0, 0, 0, 0, 0, 0};

// Button and Buzzer pins / Піни кнопок та зумера
const int BTN_PLUS = 2; // Кнопка плюса
const int BTN_MINUS = 3; // Кнопка мінуса
const int BTN_SELECT = 4; // Кнопка вибір
const int BUZZER_PIN = 5; // Пін для підключення динаміка/пищалки

// Адреси EEPROM // чисто для памяті
const int EEPROM_ADDR_ALARM_HOUR = 0;
const int EEPROM_ADDR_ALARM_MIN  = 1;
const int EEPROM_ADDR_ALARM_EN   = 2;

int currentStep = 0; // Крок у меню налаштування часу
bool inMenu = false;
bool timeModified = false; // Позначка: чи змінював користувач час/дату вручну
unsigned long lastButtonPress = 0;
int settingValues[8] = {0}; // {hour, minute, day, month, year, alarmHour, alarmMinute, alarmStatus}

// Змінні будильника
int alarmHour = 7;
int alarmMinute = 0;
bool alarmEnabled = false;
bool isRinging = false;
unsigned long buzzerTimer = 0;
bool buzzerState = false;

// Функція для отримання дня тижня українською мовою
String getDayOfWeek(uint16_t year, uint8_t month, uint8_t day) {
  // Алгоритм Зеллера
  if (month < 3) {
    month += 12;
    year--;
  }

  int K = year % 100;
  int J = year / 100;

  int h = (day + (13 * (month + 1)) / 5 + K + K / 4 + J / 4 + 5 * J) % 7;

  switch (h) {
    case 0: return "Subota";
    case 1: return "Nedilya";
    case 2: return "Ponedilok";
    case 3: return "Vivtorok";
    case 4: return "Sereda";
    case 5: return "Chetver";
    case 6: return "Pyatnytsya";
    default: return "Oshibka";
  }
}

void setup() {
  Wire.begin();
  clock.begin();

  pinMode(BTN_PLUS, INPUT_PULLUP);
  pinMode(BTN_MINUS, INPUT_PULLUP);
  pinMode(BTN_SELECT, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);

  // Читання будильника з EEPROM
  alarmHour = EEPROM.read(EEPROM_ADDR_ALARM_HOUR);
  alarmMinute = EEPROM.read(EEPROM_ADDR_ALARM_MIN);
  alarmEnabled = (EEPROM.read(EEPROM_ADDR_ALARM_EN) == 1);

  // Захист від першого запуску (якщо EEPROM порожній)
  if (alarmHour > 23) alarmHour = 7;
  if (alarmMinute > 59) alarmMinute = 0;

  lcd.init();
  lcd.backlight(); // Включаємо підсвічування дисплея

  lcd.createChar(1, v1);
  lcd.createChar(2, v2);
  lcd.createChar(3, v3);
  lcd.createChar(4, v4);
  lcd.createChar(5, v5);
  lcd.createChar(6, v6);
  lcd.createChar(7, v7);
  lcd.createChar(8, v8);
}

void loop() {
  if (isRinging) {
    handleRinging();
  } else if (inMenu) {
    handleMenu();
    checkAlarm(); // Перевіряємо будильник, навіть якщо знаходимося в меню
  } else {
    displayTime();
    checkMenuButton();
    checkAlarm();
  }
}

void displayTime() {
  // Спочатку отримуємо актуальний час
  DateTime = clock.getDateTime(); 

  // Підсвічування з 00:00 до 05:59 вимкнено
  if(DateTime.hour>=0 && DateTime.hour < 6) {
      lcd.noBacklight();
  } else {
      lcd.backlight();
  }
    
  int digits[6]; // Масив для зберігання цифр часу
  
  digits[0]=DateTime.hour/10;
  digits[1]=DateTime.hour%10;
  digits[2]=DateTime.minute/10;
  digits[3]=DateTime.minute%10;
  digits[4]=DateTime.second/10;
  digits[5]=DateTime.second%10;
  
  for(int i=0; i<6; i++){
    int e1, e2, e3, d1, d2, d3, d4, d5, d6;
    
    switch(i){
      case 0: e1=0,e2=1,e3=2;break;
      case 1: e1=3,e2=4,e3=5;break;
      case 2: e1=7,e2=8,e3=9;break;
      case 3: e1=10,e2=11,e3=12;break;
      case 4: e1=14,e2=15,e3=16;break;
      case 5: e1=17,e2=18,e3=19;break;
    }
    switch(digits[i]){
      case 0: d1=1,d2=8,d3=6,d4=1,d5=3,d6=6;break;
      case 1: d1=32,d2=2,d3=6,d4=32,d5=32,d6=6;break;
      case 2: d1=2,d2=4,d3=6,d4=1,d5=3,d6=3;break;
      case 3: d1=2,d2=4,d3=6,d4=7,d5=3,d6=6;break;
      case 4: d1=1,d2=3,d3=6,d4=32,d5=32,d6=6;break;
      case 5: d1=1,d2=4,d3=5,d4=7,d5=3,d6=6;break;
      case 6: d1=1,d2=4,d3=5,d4=1,d5=3,d6=6;break;
      case 7: d1=1,d2=8,d3=6,d4=32,d5=32,d6=6;break;
      case 8: d1=1,d2=4,d3=6,d4=1,d5=3,d6=6;break;
      case 9: d1=1,d2=4,d3=6,d4=7,d5=3,d6=6;break;
    }

    lcd.setCursor(e1,0);lcd.write((uint8_t)d1);
    lcd.setCursor(e2,0);lcd.write((uint8_t)d2);
    lcd.setCursor(e3,0);lcd.write((uint8_t)d3);
    lcd.setCursor(e1,1);lcd.write((uint8_t)d4);
    lcd.setCursor(e2,1);lcd.write((uint8_t)d5);
    lcd.setCursor(e3,1);lcd.write((uint8_t)d6);
  }

  lcd.setCursor(6,0);
  lcd.print(".");
  lcd.setCursor(13,0);
  lcd.print(".");
  lcd.setCursor(6,1);
  lcd.print(".");
  lcd.setCursor(13,1);
  lcd.print(".");
  
  // Відображення статусу будильника
  lcd.setCursor(0,2);
  if (alarmEnabled) {
    lcd.print("-- Alarm: ");
    if (alarmHour < 10) lcd.print("0");
    lcd.print(alarmHour);
    lcd.print(":");
    if (alarmMinute < 10) lcd.print("0");
    lcd.print(alarmMinute);
    lcd.print(" -- ");
  } else {
    lcd.print("--------------------");
  }

  lcd.setCursor(0,3);
  lcd.print(DateTime.day/10);
  lcd.print(DateTime.day%10);
  lcd.print("-");
  lcd.print(DateTime.month/10);
  lcd.print(DateTime.month%10);
  lcd.print("-");
  lcd.print(DateTime.year);
  lcd.setCursor(11,3);
  // Відображати день тижня
  lcd.print(getDayOfWeek(DateTime.year, DateTime.month, DateTime.day));
}

void checkAlarm() {
  // Сработка рівно на 0-й секунді
  if (alarmEnabled && DateTime.hour == alarmHour && DateTime.minute == alarmMinute && DateTime.second == 0) {
    isRinging = true;
    lcd.backlight(); // Вмикаємо дисплей, якщо він був вимкнений уночі
  }
}

void handleRinging() {
  lcd.setCursor(0,2);
  lcd.print(" *** WAKE UP! ***   ");
  
  // Переривчастий писк кожну половину секунди
  if (millis() - buzzerTimer >= 500) {
    buzzerTimer = millis();
    buzzerState = !buzzerState;
    if (buzzerState) tone(BUZZER_PIN, 2700); // 2700 Гц для більш гучного звуку
    else noTone(BUZZER_PIN);
  }

  // Вимкнення будильника будь-якою кнопкою
  if (digitalRead(BTN_PLUS) == LOW || digitalRead(BTN_MINUS) == LOW || digitalRead(BTN_SELECT) == LOW) {
    isRinging = false;
    noTone(BUZZER_PIN);
    delay(1000); // Щоб перечекати 0 секунду, інакше спрацює знову
  }
}

void checkMenuButton() {
  if (digitalRead(BTN_SELECT) == LOW) {
    delay(50); // Debounce
    if (digitalRead(BTN_SELECT) == LOW) {
      unsigned long pressStart = millis();
      while (digitalRead(BTN_SELECT) == LOW) {
        if (millis() - pressStart > 2000) { // Long press
          enterMenu();
          return;
        }
      }
    }
  }
}

void enterMenu() {
  inMenu = true;
  currentStep = 0;
  timeModified = false; // За умовчанням вважаємо, що час годинника користувач не змінював
  
  DateTime = clock.getDateTime();
  settingValues[0] = DateTime.hour;
  settingValues[1] = DateTime.minute;
  settingValues[2] = DateTime.day;
  settingValues[3] = DateTime.month;
  settingValues[4] = DateTime.year - 2000;
  settingValues[5] = alarmHour;
  settingValues[6] = alarmMinute;
  settingValues[7] = alarmEnabled ? 1 : 0;
  
  lcd.clear();
}

void handleMenu() {
  delay(50);
  
  // Якщо час годинника не змінювали кнопками, постійно оновлюємо його з RTC
  if (!timeModified) {
    DateTime = clock.getDateTime();
    settingValues[0] = DateTime.hour;
    settingValues[1] = DateTime.minute;
    settingValues[2] = DateTime.day;
    settingValues[3] = DateTime.month;
    settingValues[4] = DateTime.year - 2000;
  }

  lcd.setCursor(0, 0);
  switch (currentStep) {
    case 0: lcd.print("Set Hour: "); lcd.print(settingValues[0]); lcd.print("   "); break;
    case 1: lcd.print("Set Minute: "); lcd.print(settingValues[1]); lcd.print("   "); break;
    case 2: lcd.print("Set Day: "); lcd.print(settingValues[2]); lcd.print("   "); break;
    case 3: lcd.print("Set Month: "); lcd.print(settingValues[3]); lcd.print("   "); break;
    case 4: lcd.print("Set Year: "); lcd.print(settingValues[4] + 2000); lcd.print("   "); break;
    case 5: lcd.print("Alarm Hour: "); lcd.print(settingValues[5]); lcd.print("   "); break;
    case 6: lcd.print("Alarm Min: "); lcd.print(settingValues[6]); lcd.print("   "); break;
    case 7: lcd.print("Alarm: "); lcd.print(settingValues[7] ? "ON " : "OFF"); lcd.print("   "); break;
  }

  if (digitalRead(BTN_PLUS) == LOW) {
    delay(200); // Debounce
    if (currentStep <= 4) timeModified = true; // Фіксуємо, що час/дата змінювалися
    
    settingValues[currentStep]++;
    if (currentStep == 0 && settingValues[0] > 23) settingValues[0] = 0;
    if (currentStep == 1 && settingValues[1] > 59) settingValues[1] = 0;
    if (currentStep == 2 && settingValues[2] > 31) settingValues[2] = 1;
    if (currentStep == 3 && settingValues[3] > 12) settingValues[3] = 1;
    if (currentStep == 4 && settingValues[4] > 99) settingValues[4] = 0;
    if (currentStep == 5 && settingValues[5] > 23) settingValues[5] = 0;
    if (currentStep == 6 && settingValues[6] > 59) settingValues[6] = 0;
    if (currentStep == 7 && settingValues[7] > 1)  settingValues[7] = 0;
    lcd.clear();
  }

  if (digitalRead(BTN_MINUS) == LOW) {
    delay(200); // Debounce
    if (currentStep <= 4) timeModified = true; // Фіксуємо, що час/дата змінювалися
    
    settingValues[currentStep]--;
    if (currentStep == 0 && settingValues[0] < 0) settingValues[0] = 23;
    if (currentStep == 1 && settingValues[1] < 0) settingValues[1] = 59;
    if (currentStep == 2 && settingValues[2] < 1) settingValues[2] = 31;
    if (currentStep == 3 && settingValues[3] < 1) settingValues[3] = 12;
    if (currentStep == 4 && settingValues[4] < 0) settingValues[4] = 99;
    if (currentStep == 5 && settingValues[5] < 0) settingValues[5] = 23;
    if (currentStep == 6 && settingValues[6] < 0) settingValues[6] = 59;
    if (currentStep == 7 && settingValues[7] < 0) settingValues[7] = 1;
    lcd.clear();
  }

  if (digitalRead(BTN_SELECT) == LOW) {
    delay(50); // Debounce
    if (digitalRead(BTN_SELECT) == LOW) {
      unsigned long pressStart = millis();
      while (digitalRead(BTN_SELECT) == LOW) {
        if (millis() - pressStart > 2000) { // Long press to confirm
          saveSettings();
          return;
        }
      }
      currentStep++;
      if (currentStep > 7) currentStep = 0;
      lcd.clear();
    }
  }
}

void saveSettings() {
  // Перезаписуємо час, тільки якщо користувач його дійсно редагував кнопками
  if (timeModified) {
    clock.setDateTime(2000 + settingValues[4], settingValues[3], settingValues[2], settingValues[0], settingValues[1], 0);
  }
  
  // Зберігаємо налаштування будильника у змінні
  alarmHour = settingValues[5];
  alarmMinute = settingValues[6];
  alarmEnabled = (settingValues[7] == 1);

  // Записуємо налаштування будильника на енергонезалежну пам'ять EEPROM
  EEPROM.update(EEPROM_ADDR_ALARM_HOUR, alarmHour);
  EEPROM.update(EEPROM_ADDR_ALARM_MIN, alarmMinute);
  EEPROM.update(EEPROM_ADDR_ALARM_EN, alarmEnabled ? 1 : 0);

  inMenu = false;
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Settings Saved");
  delay(2000); // Pause after exiting menu
}